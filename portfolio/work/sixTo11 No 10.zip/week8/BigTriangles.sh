#!/bin/bash

# Module 8
# Author: Ali Raza
# Edith Cowan University, SYD Campus.

../week7/ShorterTriangle.sh | grep -E "[[:digit:]]{2}"
