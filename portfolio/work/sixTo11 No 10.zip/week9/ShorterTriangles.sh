#!/bin/bash

# Module 9
# Author: Ali Raza
# Edith Cowan University, SYD Campus

#PIPING WITH WEEK 7 WITH AWK COMMAND

../week7/ShorterTriangle.sh | awk ' /the area for a triangle with/ base/ ;  /and// '    


