#!/bin/bash

# Module 7
# Author: Ali Raza
# Edith Cowan University, SYD Campus

./IpInfo.sh | sed -n '/IP Address/p'